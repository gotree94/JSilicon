#!/usr/bin/env python3
"""
JSilicon RTL-to-GDS Script Generator
TCL 스크립트 파일들을 생성
"""

import os
import sys

def create_sdc():
    """SDC 파일 생성"""
    sdc_content = """###############################################################################
# JSilicon Timing Constraints
# Target: 200 MHz (5ns period)
###############################################################################

create_clock -name clk -period 5.0 [get_ports clk]
set_clock_uncertainty 0.5 [get_clocks clk]
set_clock_transition 0.1 [get_clocks clk]

set_input_delay -clock clk -max 1.5 [all_inputs]
set_input_delay -clock clk -min 0.5 [all_inputs]

set_output_delay -clock clk -max 1.5 [all_outputs]
set_output_delay -clock clk -min 0.5 [all_outputs]

remove_input_delay clk
remove_output_delay clk

set_driving_cell -lib_cell BUFX2 [all_inputs]
set_load 0.05 [all_outputs]
"""
    with open('constraints/jsilicon.sdc', 'w') as f:
        f.write(sdc_content)
    print("[OK] SDC created")

def create_genus_script():
    """Genus 합성 스크립트 생성"""
    genus_content = """puts "========================================="
puts "JSilicon Synthesis - FreePDK45"
puts "========================================="

set project_root [file normalize ../../]
set tech_lib $project_root/tech/lib/gscl45nm.lib
set tech_lef $project_root/tech/lef/gscl45nm.lef
set src_dir $project_root/src

puts "Reading timing library..."
read_libs $tech_lib

puts "Reading LEF file..."
read_physical -lef $tech_lef

puts "Reading RTL files..."
set_db init_hdl_search_path $src_dir

read_hdl -sv {
    alu.v
    fsm.v
    inst.v
    pc.v
    regfile.v
    switch.v
    uart.v
    jsilicon.v
}

puts "Elaborating design..."
elaborate tt_um_Jsilicon

puts "Reading SDC constraints..."
read_sdc $project_root/constraints/jsilicon.sdc

puts "Setting synthesis options..."
set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium
set_db syn_global_effort medium

puts "Phase 1: Generic Synthesis"
syn_generic

puts "Phase 2: Technology Mapping"
syn_map

puts "Phase 3: Optimization"
syn_opt

puts "Generating Reports..."
set report_dir $project_root/reports/synthesis
file mkdir $report_dir

redirect $report_dir/area.rpt {report_area}
redirect $report_dir/gates.rpt {report_gates}
redirect $report_dir/power.rpt {report_power}
redirect $report_dir/timing.rpt {report_timing -nworst 10}
redirect $report_dir/qor.rpt {report_qor}

puts "Writing Output Files..."
set netlist_dir $project_root/results/netlist
set work_dir $project_root/work/synthesis

file mkdir $netlist_dir
file mkdir $work_dir

write_hdl > $netlist_dir/tt_um_Jsilicon_synth.v
write_sdc > $work_dir/tt_um_Jsilicon_synth.sdc
write_sdf -timescale ns > $project_root/results/timing/tt_um_Jsilicon_synth.sdf
write_db $work_dir/tt_um_Jsilicon_synth.db

puts ""
puts "SYNTHESIS COMPLETE!"
puts ""

exit
"""
    with open('scripts/genus/synthesis.tcl', 'w') as f:
        f.write(genus_content)
    os.chmod('scripts/genus/synthesis.tcl', 0o755)
    print("[OK] Genus script created")

def create_mmmc_script():
    """MMMC 스크립트 생성"""
    mmmc_content = """set project_root [file normalize ../../]
set tech_lib $project_root/tech/lib/gscl45nm.lib
set sdc_file $project_root/work/synthesis/tt_um_Jsilicon_synth.sdc

puts "MMMC Configuration..."

if { ![file exists $tech_lib] } {
    puts "ERROR: Library not found"
    exit 1
}

if { ![file exists $sdc_file] } {
    puts "WARNING: SDC not found"
    set sdc_file ""
}

create_library_set -name LIB_TYPICAL -timing $tech_lib
create_rc_corner -name RC_TYPICAL -temperature 27
create_delay_corner -name DELAY_TYPICAL -library_set LIB_TYPICAL -rc_corner RC_TYPICAL

if { $sdc_file != "" } {
    create_constraint_mode -name CONSTRAINTS -sdc_files $sdc_file
} else {
    create_constraint_mode -name CONSTRAINTS -sdc_files {}
}

create_analysis_view -name VIEW_TYPICAL -constraint_mode CONSTRAINTS -delay_corner DELAY_TYPICAL
set_analysis_view -setup VIEW_TYPICAL -hold VIEW_TYPICAL

puts "MMMC complete"
"""
    with open('scripts/innovus/mmmc.tcl', 'w') as f:
        f.write(mmmc_content)
    print("[OK] MMMC script created")

def create_pnr_script():
    """Innovus P&R 스크립트 생성"""
    pnr_content = """set DESIGN_NAME "tt_um_Jsilicon"
set project_root [file normalize ../../]

puts "JSilicon P&R Flow"

set init_lef_file $project_root/tech/lef/gscl45nm.lef
set init_verilog $project_root/results/netlist/${DESIGN_NAME}_synth.v
set init_top_cell $DESIGN_NAME
set init_pwr_net vdd
set init_gnd_net gnd
set init_mmmc_file $project_root/scripts/innovus/mmmc.tcl

puts "Initializing design..."
init_design

puts "Floorplan..."
floorPlan -r 1.0 0.70 10.0 10.0 10.0 10.0
catch {editPin -fixOverlap 1 -unit MICRON -spreadType start -spreadDirection clockwise -pin [dbGet top.terms.name -e]}

puts "Power Planning..."
globalNetConnect vdd -type pgpin -pin vdd -inst * -override
globalNetConnect gnd -type pgpin -pin gnd -inst * -override
globalNetConnect vdd -type tiehi -inst *
globalNetConnect gnd -type tielo -inst *
catch {addRing -nets {vdd gnd} -type core_rings -layer {metal9 metal10} -width 2.0 -spacing 1.0 -offset 5.0}
catch {addStripe -nets {vdd gnd} -layer metal8 -direction vertical -width 1.0 -spacing 10.0 -number_of_sets 3}
sroute -connect {corePin} -nets {vdd gnd}

puts "Placement..."
setPlaceMode -congEffort high -timingDriven true
place_design
saveDesign $project_root/work/pnr/jsilicon_placed.enc

puts "Pre-CTS Optimization..."
optDesign -preCTS

puts "Clock Tree Synthesis..."
set_ccopt_property buffer_cells {BUFX2 BUFX4}
set_ccopt_property inverter_cells {INVX1 INVX2 INVX4}
catch {create_ccopt_clock_tree_spec -immediate; ccopt_design}
saveDesign $project_root/work/pnr/jsilicon_cts.enc

puts "Post-CTS Optimization..."
optDesign -postCTS

puts "Routing..."
setNanoRouteMode -drouteFixAntenna true
setNanoRouteMode -droutePostRouteSwapVia true
routeDesign

puts "Post-Route Optimization..."
setOptMode -addInstancePrefix POSTROUTE
catch {optDesign -postRoute}

puts "Adding Filler Cells..."
setFillerMode -corePrefix FILL -core "FILL*"
addFiller

puts "Generating Reports..."
set report_dir $project_root/reports/pnr
file mkdir $report_dir

verifyGeometry -report $report_dir/geometry.rpt
verifyConnectivity -report $report_dir/connectivity.rpt
report_timing -max_paths 10 -nworst 1 -late > $report_dir/timing_setup.rpt
report_timing -max_paths 10 -nworst 1 -early > $report_dir/timing_hold.rpt
report_timing -late > $report_dir/timing_summary.rpt
report_power > $report_dir/power_final.rpt
report_area > $report_dir/area_final.rpt
report_constraint -all_violators > $report_dir/violations.rpt
summaryReport -outfile $report_dir/summary.rpt

puts "Writing Outputs..."
set result_dir $project_root/results
file mkdir $result_dir/def

defOut -floorplan -netlist -routing $result_dir/def/${DESIGN_NAME}.def
saveNetlist $result_dir/netlist/${DESIGN_NAME}_final.v
saveDesign $project_root/work/pnr/jsilicon_final.enc

puts "P&R COMPLETE!"
exit
"""
    with open('scripts/innovus/pnr_flow.tcl', 'w') as f:
        f.write(pnr_content)
    os.chmod('scripts/innovus/pnr_flow.tcl', 0o755)
    print("[OK] P&R script created")

def create_gds_script():
    """GDS 생성 스크립트"""
    gds_content = """set DESIGN_NAME "tt_um_Jsilicon"
set project_root [file normalize ../../]

puts "GDS Generation..."

if { [file exists jsilicon_final.enc.dat] } {
    restoreDesign jsilicon_final.enc.dat $DESIGN_NAME
} else {
    puts "ERROR: Database not found"
    exit 1
}

fit

puts "RC Extraction..."
extractRC

set extraction_dir $project_root/results/extraction
file mkdir $extraction_dir

rcOut -spef $extraction_dir/tt_um_Jsilicon.spef
write_sdf -version 3.0 $extraction_dir/tt_um_Jsilicon.sdf
saveDesign jsilicon_extracted.enc

puts "Final Reports..."
set final_dir $project_root/reports/final
file mkdir $final_dir

report_timing -late > $final_dir/timing_summary.rpt
report_power > $final_dir/power.rpt
report_area > $final_dir/area.rpt
summaryReport -outfile $final_dir/summary.rpt

puts "GDS Streamout..."
set gds_dir $project_root/results/gds
file mkdir $gds_dir

set gds_file $gds_dir/tt_um_Jsilicon.gds
streamOut $gds_file

if { [file exists $gds_file] } {
    set file_size [file size $gds_file]
    set file_size_kb [expr $file_size / 1024]
    puts "GDS size: ${file_size_kb} KB"
}

puts "GDS COMPLETE!"
exit
"""
    with open('scripts/innovus/generate_gds.tcl', 'w') as f:
        f.write(gds_content)
    print("[OK] GDS script created")

def main():
    """메인 함수"""
    print("Creating TCL scripts...")
    print()
    
    create_sdc()
    create_genus_script()
    create_mmmc_script()
    create_pnr_script()
    create_gds_script()
    
    print()
    print("[OK] All scripts created successfully!")

if __name__ == "__main__":
    main()
